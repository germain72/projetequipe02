/**
 * 
 */
/**
 * @author romua
 *
 */
package filrouge.admin.bean;