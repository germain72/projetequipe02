/**
 * 
 */
/**
 * @author Formation
 *
 */
package filrouge.jeu.services;