/**
 * 
 */
/**
 * @author Formation
 *
 */
package filrouge.jeu.bean;