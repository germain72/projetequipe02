/**
 * 
 */
/**
 * @author Formation
 *
 */
package filrouge.jeu.dao;