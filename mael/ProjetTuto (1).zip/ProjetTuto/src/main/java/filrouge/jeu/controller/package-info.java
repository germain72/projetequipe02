/**
 * 
 */
/**
 * @author Formation
 *
 */
package filrouge.jeu.controller;