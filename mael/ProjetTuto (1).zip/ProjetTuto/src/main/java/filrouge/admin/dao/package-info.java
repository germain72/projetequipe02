/**
 * 
 */
/**
 * @author Formation
 *
 */
package filrouge.admin.dao;