/**
 * 
 */
/**
 * @author Formation
 *
 */
package filrouge.admin.bean;