package filrouge.admin.controller;

import org.springframework.stereotype.Controller;

@Controller
public class ModifierClientController {

}
